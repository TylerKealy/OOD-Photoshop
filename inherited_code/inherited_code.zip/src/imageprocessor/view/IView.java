package imageprocessor.view;

/**
 * Represents a class that can render messages.
 */
public interface IView {

}
