package imageprocessor.controller;

/**
 * Represents a ImageProcessor.model.controller that can take in commands and perform operations
 * on the image.
 */
public interface IController {

}
