package imageprocessor.model.imageoperations.pixelfilters;

public class Posn {
  int r;
  int c;

  public Posn(int x, int y) {
    this.r = x;
    this.c = y;
  }

}
