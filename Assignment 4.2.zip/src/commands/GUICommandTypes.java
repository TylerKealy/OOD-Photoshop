package commands;

/**
 * CommandTypes for GUI photoshop commands.
 */
public enum GUICommandTypes { Brighten, Component, Flip, Kernel, Load, Save, Transform }
