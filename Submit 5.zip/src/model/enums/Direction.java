package model.enums;

/**
 * Direction. Used for flipping.
 */
public enum Direction { Horizontal, Vertical }
