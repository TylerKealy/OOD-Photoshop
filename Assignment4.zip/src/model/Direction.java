package model;

/**
 * Direction. Used for flipping.
 */
public enum Direction { Horizontal, Vertical }
