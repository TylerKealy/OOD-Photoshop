package model;

/**
 * Stores the RGB value of a pixel.
 */
public class RGB {
  public int r;
  public int g;
  public int b;

  public RGB(int r, int g, int b) {
    this.r = r;
    this.g = g;
    this.b = b;
  }
}
