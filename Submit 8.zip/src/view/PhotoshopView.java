package view;

/**
 * The view for the Photoshop program.
 */
public interface PhotoshopView {
}
